package com.linkui.ThreadRunTest;

/*
 * ADB GUI Toolbox project
 * Version: beta v1.0
 * Author: Linkui Lu
 * Last time update: 04/28/2015
 */

public class MainWindow {
	public static void main(String args[]){
		TestWindow mainWindow = new TestWindow();
		mainWindow.show();
	}

}
