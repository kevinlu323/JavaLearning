package com.linkui.ThreadRunTest;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class RunInThread {
	static Runtime run = Runtime.getRuntime();
	static Process pro;
	/**
	 * @param args
	 */
	/*public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		pro=RunInThread.run.exec("adb logcat");
		RunnerThread rt= new RunnerThread();
		ThreadTest2 t2 = new ThreadTest2();
		rt.start();
		t2.start();
		System.out.println("Main Thread terminates");

	}*/
	public void RunCommnad()throws IOException{
		pro=RunInThread.run.exec("adb logcat");
		RunnerThread rt= new RunnerThread();
		ThreadTest2 t2 = new ThreadTest2();
		rt.start();
		t2.start();
		System.out.println("Main Thread terminates");
	}
}

class RunnerThread extends Thread{
	public void run(){
		try{
		//Process pro = RunInThread.run.exec("adb devices");
		BufferedInputStream bIn = new BufferedInputStream(RunInThread.pro.getInputStream());
		BufferedReader inBf = new BufferedReader(new InputStreamReader(bIn));
		String lineStr;
		while ((lineStr= inBf.readLine()) != null){
            System.out.println(lineStr);
            TestWindow.jta.append(lineStr);
            TestWindow.jta.append("\n");
            TestWindow.sBar.setValue(TestWindow.sBar.getMaximum());
		}
		} catch(IOException e1){
			e1.printStackTrace();
		}
	}
}

class ThreadTest2 extends Thread{
	public void run(){
		System.out.println("Thread 2 starts");
		try{
			ThreadTest2.sleep(5000);
		} catch (InterruptedException ie){
			ie.printStackTrace();
		}
		System.out.println("Thread1 is terminated by Thread2");
		//RunInThread.run.exit(1);
		RunInThread.pro.destroy();
		
	}
}