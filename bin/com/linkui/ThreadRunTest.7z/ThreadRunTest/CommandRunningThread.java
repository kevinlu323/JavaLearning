package com.linkui.ThreadRunTest;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CommandRunningThread extends Thread{
	public void run(){
		try{
			if (TestWindow.needFilter==-1){
				//Process pro = RunInThread.run.exec("adb devices");
				BufferedInputStream bIn = new BufferedInputStream(CommandRunner.pro.getInputStream());
				BufferedReader inBf = new BufferedReader(new InputStreamReader(bIn));
				String lineStr;
				while ((lineStr= inBf.readLine()) != null){
		            //System.out.println(lineStr);
		            TestWindow.jta.append(lineStr);
					TestWindow.jta.append("\n");
					/*if(lineStr.contains("leak")){
					TestWindow.jta.append(lineStr);
		            TestWindow.jta.append("\n");}*/
		            TestWindow.sBar.setValue(TestWindow.sBar.getMaximum());
				}
			}
			else if(TestWindow.needFilter==0){
				//Process pro = RunInThread.run.exec("adb devices");
				BufferedInputStream bIn = new BufferedInputStream(CommandRunner.pro.getInputStream());
				BufferedReader inBf = new BufferedReader(new InputStreamReader(bIn));
				String lineStr;
				while ((lineStr= inBf.readLine()) != null){
					if(lineStr.contains(TestWindow.outputFilter)){
					TestWindow.jta.append(lineStr);
		            TestWindow.jta.append("\n");}
		            TestWindow.sBar.setValue(TestWindow.sBar.getMaximum());
				}
			}
			else{
				TestWindow.jta.append("Filter not set");
			}
		} catch(IOException e1){
			e1.printStackTrace();
		}
	}
}
