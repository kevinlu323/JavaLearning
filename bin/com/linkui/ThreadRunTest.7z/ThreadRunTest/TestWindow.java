package com.linkui.ThreadRunTest;


import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class TestWindow {
	
	JFrame frame = new JFrame("GUI Thread Running Test");
	JLabel label = new JLabel("ADB GUI Toolbox v1.0. Developped by: Linkui");
	JButton startBtn = new JButton("Start");
	JButton stopBtn = new JButton("Stop");
	JButton clearBtn = new JButton ("Clear Results");
	static JTextArea jta = new JTextArea(30,80);
	static JScrollPane scrollPane = new JScrollPane(jta);
	static JScrollBar sBar = scrollPane.getVerticalScrollBar();
	JComboBox<String> jcb = new JComboBox<String>();
	
	String commandToRun = new String();
	static String outputFilter = new String("leak");
	static int needFilter = -1;
	
	public TestWindow(){
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new BorderLayout());
		
		jcb.addItem("adb devices");
		jcb.addItem("adb root");
		jcb.addItem("adb remount");
		jcb.addItem("show logcat");
		jcb.addItem("find leak");
		
		// add button & TextArea on the layout
		frame.getContentPane().add(startBtn,BorderLayout.NORTH);
		frame.getContentPane().add(stopBtn,BorderLayout.CENTER);
		frame.getContentPane().add(scrollPane,BorderLayout.SOUTH);
		frame.getContentPane().add(jcb,BorderLayout.EAST);
		frame.getContentPane().add(clearBtn,BorderLayout.WEST);
		jta.setLineWrap(true);
		
		frame.pack();
		
		startBtn.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent ae){
        		CommandRunner crStart = new CommandRunner();
        		System.out.println(commandToRun);
        		crStart.setCommand(commandToRun);
        		crStart.runCommand();
        	}
        });
		
		stopBtn.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent ae){
        		CommandRunner crStop = new CommandRunner();
        		crStop.stopCommand();
        	}
        });
		
		clearBtn.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent ae){
        		jta.setText(null);
        	}
        });
		
		jcb.addActionListener (new ActionListener () {
		    public void actionPerformed(ActionEvent e) {
		        switch((String)jcb.getSelectedItem()){
		        case "show logcat":
		        	commandToRun="adb logcat";
		        	needFilter = -1;
		        	System.out.println("Command: "+ commandToRun);
		        	break;
		        case "find leak":
		        	commandToRun = "adb logcat";
		        	outputFilter = "leak";
		        	needFilter = 0;
		        	System.out.println("Command: find leak in"+ commandToRun);
		        	break;
		        default:
		        	break;
		        }
		    }
		});
		
		/*jcb.addItemListener(new ItemListener() {
            //
            // Listening if a new items of the combo box has been selected.
            //
            public void itemStateChanged(ItemEvent event) {
                JComboBox comboBox = (JComboBox) event.getSource();

                // The item affected by the event.
                Object item = event.getItem();

                jta.setText("Affected items: " + item.toString());

                if (event.getStateChange() == ItemEvent.SELECTED) {
                    jta.setText(item.toString() + " selected.");
                }

                if (event.getStateChange() == ItemEvent.DESELECTED) {
                    jta.setText(item.toString() + " deselected.");
                }
            }
        });*/
	}
	
	public void show(){
		frame.setVisible(true);
	}
	
	
}
