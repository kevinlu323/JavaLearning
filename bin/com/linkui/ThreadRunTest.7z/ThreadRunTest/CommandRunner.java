package com.linkui.ThreadRunTest;

import java.io.IOException;

public class CommandRunner {
	static Runtime run = Runtime.getRuntime();
	static Process pro;
	String commandToRun = new String("adb logcat");
	
	public void runCommand(){
		try{
		pro=CommandRunner.run.exec(commandToRun);
		CommandRunningThread crt= new CommandRunningThread();
		crt.start();
		} catch (IOException e){
			System.out.println("Error while running");
			e.printStackTrace();
		}
	}
	
	public void stopCommand(){
		StopRunnerThread srt = new StopRunnerThread();
		srt.start();
	}
	
	public void setCommand(String _commandToRun){
		this.commandToRun=_commandToRun;
	}
}
