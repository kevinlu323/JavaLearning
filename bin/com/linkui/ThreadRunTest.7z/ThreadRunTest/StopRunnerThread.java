package com.linkui.ThreadRunTest;

public class StopRunnerThread extends Thread{
	public void run(){
		/*try{
			StopRunnerThread.sleep(5000);
		} catch (InterruptedException ie){
			ie.printStackTrace();
		}
		System.out.println("Thread1 is terminated by Thread2");
		//RunInThread.run.exit(1);
*/		
		System.out.println("Thread1 is terminated by Thread2");
		CommandRunner.pro.destroy();
		
	}
}
